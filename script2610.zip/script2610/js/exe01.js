function mudarTexto(){
    const titulo = document.getElementById("titulo")
    titulo.classList.add("titulo")
    titulo.textContent = "Hello World!"
}