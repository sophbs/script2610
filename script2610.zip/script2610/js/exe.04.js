
const item = document.getElementById("item");
const lista = document.getElementById("lista");

function adicionar(){
       const textoItem = item.value.trim();

       if(textoItem !== ""){
        const novoItem = document.createElement("li");
        item.focus();
       }
}